const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post('/api/order', (req, res) => {
  const { cart, address } = req.body;
  console.log('New Order:', cart, address);
  res.json({ message: 'Order received!', status: 'success' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
